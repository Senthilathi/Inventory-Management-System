﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagement.Service
{
    public abstract class OrderCommand
    {
        public abstract void Execute(List<Item> items, Item item);
    }
}
