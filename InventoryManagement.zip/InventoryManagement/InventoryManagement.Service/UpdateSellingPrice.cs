﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagement.Service
{
    public class UpdateSellingPrice : OrderCommand 
    {
        public override void Execute(List<Item> stockItems, Item updateSellingProceItem)
        {
            //var item = stockItems.Where(X => X.Name == updateSellingProceItem.Name).First();
            //item.SellingPrice = updateSellingProceItem.SellingPrice;

            (from p in stockItems where p.Name == updateSellingProceItem.Name select p).ToList().ForEach(x => x.SellingPrice = updateSellingProceItem.SellingPrice);
        }
    }
}
