﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagement.Service
{
    public class DeleteOrder : OrderCommand 
    {
        public override void Execute(List<Item> stockItems, Item deleteItem)
        {
            var item = stockItems.Where(X => X.Name == deleteItem.Name).First();
            item.IsDelete = true;
        }
    }
}
