﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using InventoryManagement.Service;

namespace InventoryManagement.UnitTest
{
    [TestClass]
    public class UpdateSellTestCase
    {
        OrderInvoker orderInvoker = new OrderInvoker();

        [TestMethod]
        public void UpdateSell1()
        {
            orderInvoker.ExecuteCommand(CommandOption.Create, "Tab01", 57, 84.98);
            orderInvoker.ExecuteCommand(CommandOption.UpdateBuy, "Tab01", 100);
            orderInvoker.ExecuteCommand(CommandOption.UpdateSell, "Tab01", 2);
        }
        [TestMethod]
        public void UpdateSell2()
        {
            orderInvoker.ExecuteCommand(CommandOption.Create, "Food01", 1.47, 3.98);
            orderInvoker.ExecuteCommand(CommandOption.UpdateSell, "Food01", 1);
        }
    }
}
