﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using InventoryManagement.Service;

namespace InventoryManagement.UnitTest
{
    [TestClass]
    public class CreateTestCase
    {
        OrderInvoker orderInvoker = new OrderInvoker();

        [TestMethod]
        public void CreateItem1()
        {
            orderInvoker.ExecuteCommand(CommandOption.Create, "Book01", 10.50, 13.79);
        }
        [TestMethod]
        public void CreateItem2()
        {
            orderInvoker.ExecuteCommand(CommandOption.Create, "Food01", 1.47, 3.98);
        }
        [TestMethod]
        public void CreateItem3()
        {
            orderInvoker.ExecuteCommand(CommandOption.Create, "Med01", 30.63, 34.29);
        }
        [TestMethod]
        public void CreateItem4()
        {
            orderInvoker.ExecuteCommand(CommandOption.Create, "Tab01", 57, 84.98);
        }
    }
}
