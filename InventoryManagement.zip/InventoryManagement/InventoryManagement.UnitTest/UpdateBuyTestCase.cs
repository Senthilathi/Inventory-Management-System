﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using InventoryManagement.Service;

namespace InventoryManagement.UnitTest
{
    [TestClass]
    public class UpdateBuyTestCase
    {
        OrderInvoker orderInvoker = new OrderInvoker();

        [TestMethod]
        public void UpdateBuy1()
        {
            orderInvoker.ExecuteCommand(CommandOption.Create, "Tab01", 57, 84.98);
            orderInvoker.ExecuteCommand(CommandOption.UpdateBuy, "Tab01", 100);
        }
        [TestMethod]
        public void UpdateBuy2()
        {
            orderInvoker.ExecuteCommand(CommandOption.Create, "Food01", 1.47, 3.98);
            orderInvoker.ExecuteCommand(CommandOption.UpdateBuy, "Food01", 500);
        }
        [TestMethod]
        public void UpdateBuy3()
        {
            orderInvoker.ExecuteCommand(CommandOption.Create, "Book01", 10.50, 13.79);
            orderInvoker.ExecuteCommand(CommandOption.UpdateBuy, "Book01", 100);
        }
        [TestMethod]
        public void UpdateBuy4()
        {
            orderInvoker.ExecuteCommand(CommandOption.Create, "Med01", 30.63, 34.29);
            orderInvoker.ExecuteCommand(CommandOption.UpdateBuy, "Med01", 100);
        }
    }
}
