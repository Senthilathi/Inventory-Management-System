﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using InventoryManagement.Service;

namespace InventoryManagement.UnitTest
{
    [TestClass]
    public class DeleteTestCase
    {
        OrderInvoker orderInvoker = new OrderInvoker();

        [TestMethod]
        public void Delete()
        {
            orderInvoker.ExecuteCommand(CommandOption.Create, "Book01", 10.50, 13.79);
            orderInvoker.ExecuteCommand(CommandOption.UpdateBuy, "Book01", 100);
        }
    }
}
