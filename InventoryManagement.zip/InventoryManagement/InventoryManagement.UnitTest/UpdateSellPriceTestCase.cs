﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using InventoryManagement.Service;

namespace InventoryManagement.UnitTest
{
    [TestClass]
    public class UpdateSellPriceTestCase
    {
        OrderInvoker orderInvoker = new OrderInvoker();

        [TestMethod]
        public void UpdateSellPrice1()
        {
            orderInvoker.ExecuteCommand(CommandOption.Create, "Food01", 1.47, 3.98);
            orderInvoker.ExecuteCommand(CommandOption.UpdateBuy, "Food01", 500);
            orderInvoker.ExecuteCommand(CommandOption.UpdateSellPrice, "Food01", 3.50);
        }
    }
}
